import sys, random, grader, parse

def random_play_single_ghost(problem):
    #Your p1 code here
    solution = ''
    return solution

if __name__ == "__main__":
    try: test_case_id = int(sys.argv[1])
    except: test_case_id = -6
    problem_id = 1
    grader.grade(problem_id, test_case_id, random_play_single_ghost, parse.read_layout_problem)